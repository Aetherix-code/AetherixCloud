import { useState } from 'react'
import { Link, useNavigate } from '@tanstack/react-router'
import { FolderKanban, Plus } from 'lucide-react'
import { Page, PageHeader } from '@/components/layout'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Dialog, DialogContent, DialogHeader } from '@/components/ui/dialog'
import { Empty, ListSkeleton, QueryError } from '@/components/ui/states'
import { Field, Input } from '@/components/ui/input'
import { api } from '@/lib/api'
import { keys, useAction, useProjects } from '@/lib/queries'
import { timeAgo } from '@/lib/utils'

export function ProjectsPage() {
  const q = useProjects()
  const nav = useNavigate()
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [desc, setDesc] = useState('')
  const create = useAction((a: { name: string; description: string }) => api.projects.createProject(a), {
    invalidate: [keys.projects],
    success: 'Project created',
    onSuccess: (r) => {
      setOpen(false)
      setName('')
      setDesc('')
      if (r.project) void nav({ to: '/projects/$projectId', params: { projectId: r.project.id }, search: {} })
    },
  })
  return (
    <Page wide>
      <PageHeader title="Projects" description="Each project groups services and environments." actions={<Button onClick={() => setOpen(true)}><Plus />New project</Button>} />
      {q.isLoading ? (
        <ListSkeleton />
      ) : q.error ? (
        <QueryError error={q.error} what="projects" />
      ) : !q.data?.length ? (
        <Card><Empty title="No projects yet" icon={<FolderKanban className="size-8" />}>Create a project, then add services from a GitHub repo, a Docker image or a template.</Empty></Card>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {q.data.map((p) => (
            <Link key={p.id} to="/projects/$projectId" params={{ projectId: p.id }} search={{}}>
              <Card className="h-full p-4 transition-colors hover:border-primary/60">
                <div className="flex items-center gap-2"><FolderKanban className="size-4 text-primary" /><span className="font-medium">{p.name}</span></div>
                <p className="mt-2 line-clamp-2 min-h-8 text-sm text-muted-foreground">{p.description || 'No description'}</p>
                <p className="mt-3 text-xs text-muted-foreground">Created {timeAgo(p.createdAt)}</p>
              </Card>
            </Link>
          ))}
        </div>
      )}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader title="New project" description="A production environment is created automatically." />
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); create.mutate({ name, description: desc }) }}>
            <Field label="Name"><Input value={name} onChange={(e) => setName(e.target.value)} required autoFocus pattern="[a-z0-9][a-z0-9-]*" title="lowercase letters, digits and dashes" /></Field>
            <Field label="Description"><Input value={desc} onChange={(e) => setDesc(e.target.value)} /></Field>
            <div className="flex justify-end"><Button type="submit" disabled={create.isPending || !name}>Create</Button></div>
          </form>
        </DialogContent>
      </Dialog>
    </Page>
  )
}
