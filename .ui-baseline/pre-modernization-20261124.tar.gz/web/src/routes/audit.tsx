import { useState } from 'react'
import { Page, PageHeader } from '@/components/layout'
import { Badge } from '@/components/ui/badge'
import { Card } from '@/components/ui/card'
import { Select } from '@/components/ui/input'
import { Empty, ListSkeleton, NotAvailable, QueryError } from '@/components/ui/states'
import { useAudit } from '@/lib/queries'
import { timeAgo } from '@/lib/utils'

export function AuditSettings() {
  const [prefix, setPrefix] = useState('')
  const q = useAudit(prefix)
  return (
    <Page wide>
      <PageHeader
        title="Audit log"
        description="Every dashboard, API and MCP action, including the agent that made it."
        actions={
          <Select className="w-auto" value={prefix} onChange={(e) => setPrefix(e.target.value)} aria-label="Filter">
            <option value="">All actions</option>
            <option value="oauth.">OAuth</option>
            <option value="/aetherix.v1.">Dashboard & API</option>
          </Select>
        }
      />
      {q.isLoading ? <ListSkeleton /> : q.error ? <QueryError error={q.error} what="the audit log" /> : q.data === null ? <NotAvailable what="The audit log" /> : !q.data?.length ? (
        <Card><Empty title="No audit entries" /></Card>
      ) : (
        <Card className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b text-left text-xs text-muted-foreground">
              <tr><th className="p-3 font-medium">When</th><th className="p-3 font-medium">Actor</th><th className="p-3 font-medium">Via</th><th className="p-3 font-medium">Action</th><th className="p-3 font-medium">Result</th></tr>
            </thead>
            <tbody className="divide-y">
              {q.data!.map((e) => (
                <tr key={e.id}>
                  <td className="whitespace-nowrap p-3 text-xs text-muted-foreground">{timeAgo(e.time)}</td>
                  <td className="p-3">{e.actorEmail || e.actorUserId || '—'}</td>
                  <td className="p-3"><Badge tone={e.via === 'mcp' ? 'info' : 'neutral'}>{e.via}{e.client && e.via === 'mcp' ? ` · ${e.client}` : ''}</Badge></td>
                  <td className="p-3"><div className="font-mono text-xs">{e.action}</div>{e.summary && <div className="text-xs text-muted-foreground">{e.summary}</div>}</td>
                  <td className="p-3">{e.ok ? <Badge tone="success">ok</Badge> : <Badge tone="danger" title={e.error}>failed</Badge>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </Page>
  )
}
