import { useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { getRouteApi, useNavigate } from '@tanstack/react-router'
import { Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Select } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Empty, QueryError } from '@/components/ui/states'
import { ProjectCanvas } from '@/features/canvas'
import { NewServiceDialog } from '@/features/new-service'
import { ServicePanel } from '@/features/service-panel'
import { api } from '@/lib/api'
import { refEdges } from '@/lib/refs'
import { useProject } from '@/lib/queries'

const route = getRouteApi('/app/projects/$projectId')

export function ProjectPage() {
  const { projectId } = route.useParams()
  const search = route.useSearch()
  const nav = useNavigate()
  const q = useProject(projectId)
  const envs = q.data?.environments ?? []
  const env = envs.find((e) => e.id === search.env) ?? envs.find((e) => !e.ephemeral) ?? envs[0]
  const services = useMemo(() => (q.data?.services ?? []).filter((s) => !env || s.environmentId === env.id), [q.data, env])

  const vars = useQuery({
    queryKey: ['variables', env?.id ?? '', '*'],
    enabled: !!env,
    queryFn: async () => (await api.projects.listVariables({ environmentId: env!.id, serviceId: '*' })).variables,
  })
  const reps = useQuery({ queryKey: ['project', 'replicas', projectId], queryFn: async () => (await api.services.listReplicas({})).replicas, refetchInterval: 6000 })
  const doms = useQuery({
    queryKey: ['project', 'domains', projectId, services.map((s) => s.id).join()],
    enabled: services.length > 0,
    queryFn: async () => (await Promise.all(services.map((s) => api.services.listDomains({ serviceId: s.id })))).flatMap((r) => r.domains),
  })

  const edges = useMemo(() => {
    const names = new Map(services.map((s) => [s.id, s.name]))
    return refEdges(
      (vars.data ?? []).filter((v) => names.has(v.serviceId)).map((v) => ({ serviceName: names.get(v.serviceId)!, value: v.value })),
      new Set(services.map((s) => s.name)),
    )
  }, [vars.data, services])

  const setSearch = (patch: Record<string, string | undefined>) =>
    void nav({ to: '/projects/$projectId', params: { projectId }, search: (prev: Record<string, unknown>) => ({ ...prev, ...patch }) as never })

  if (q.isLoading) return <div className="p-6"><Skeleton className="h-[60vh] w-full" /></div>
  if (q.error) return <div className="p-6"><QueryError error={q.error} what="project" /></div>
  const selected = services.find((s) => s.id === search.service)

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-3 border-b px-4 py-2.5">
        <h1 className="text-base font-semibold">{q.data?.project?.name}</h1>
        {envs.length > 0 && (
          <Select className="h-8 w-auto text-xs" value={env?.id} onChange={(e) => setSearch({ env: e.target.value, service: undefined })} aria-label="Environment">
            {envs.map((e) => <option key={e.id} value={e.id}>{e.name}{e.ephemeral ? ' (preview)' : ''}</option>)}
          </Select>
        )}
        <Button size="sm" className="ml-auto" onClick={() => setSearch({ new: 'github' })}><Plus />New</Button>
      </div>
      <div className="flex min-h-0 flex-1">
        <div className="dot-grid relative min-w-0 flex-1">
          {services.length === 0 ? (
            <Empty title="No services in this environment">Press <kbd className="rounded border bg-muted px-1">⌘K</kbd> or “New” to deploy from GitHub, an image or a template. Database templates attach persistent storage automatically; you can also add volumes under a service’s Settings.</Empty>
          ) : (
            <ProjectCanvas
              projectId={projectId}
              environmentId={env?.id ?? ''}
              services={services}
              replicas={reps.data ?? []}
              domains={doms.data ?? []}
              edges={edges}
              variables={vars.data ?? []}
              selected={search.service}
              onSelect={(id) => setSearch({ service: id, tab: undefined })}
            />
          )}
        </div>
        {selected && env && (
          <ServicePanel key={selected.id} service={selected} environmentId={env.id} services={services} tab={search.tab ?? 'deployments'} onTab={(tab) => setSearch({ tab })} onClose={() => setSearch({ service: undefined, tab: undefined })} />
        )}
      </div>
      {search.new && (
        <NewServiceDialog
          projectId={projectId}
          environment={env?.id}
          kind={search.new}
          template={search.template}
          onClose={() => setSearch({ new: undefined, template: undefined })}
          onCreated={(id) => setSearch({ new: undefined, template: undefined, service: id })}
        />
      )}
    </div>
  )
}
