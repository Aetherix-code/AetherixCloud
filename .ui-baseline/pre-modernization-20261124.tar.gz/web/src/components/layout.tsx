import { Link, Outlet, useNavigate } from '@tanstack/react-router'
import { Activity, Bot, Cloud, FolderKanban, GitBranch, LogOut, Moon, ScrollText, Search, Server, Settings, Sun, Users } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { CommandPalette, openPaletteEvent } from '@/components/command-palette'
import { useAuth } from '@/lib/auth'
import { useLiveEvents } from '@/lib/live'
import { isMock } from '@/lib/api'
import { useStatus } from '@/lib/queries'
import { useTheme } from '@/lib/theme'
import { cn } from '@/lib/utils'

const navItem = 'flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm text-muted-foreground hover:bg-muted hover:text-foreground [&.active]:bg-accent [&.active]:text-foreground'

export function AppLayout() {
  const { user, logout, authDisabled, status: authStatus } = useAuth()
  const { live } = useLiveEvents(authStatus === 'authed')
  const status = useStatus()
  const [theme, toggleTheme] = useTheme()
  const nav = useNavigate()
  const s = status.data
  return (
    <div className="flex h-full">
      <aside className="hidden w-56 shrink-0 flex-col border-r bg-card md:flex">
        <div className="flex h-14 items-center gap-2 border-b px-4">
          <div className="grid size-7 place-items-center rounded-md bg-primary text-sm font-bold text-primary-foreground">A</div>
          <div className="min-w-0">
            <div className="truncate text-sm font-semibold leading-tight">{s?.cluster?.name ?? 'AetherixCloud'}</div>
            <div className="truncate text-[11px] text-muted-foreground">{s?.servedBy ? `via ${s.servedBy}` : 'connecting…'}</div>
          </div>
        </div>
        <nav className="flex-1 space-y-0.5 p-2" aria-label="Main">
          <Link to="/" className={navItem} activeOptions={{ exact: true }}><FolderKanban className="size-4" />Projects</Link>
          <Link to="/cluster" className={navItem}><Server className="size-4" />Cluster</Link>
          <Link to="/activity" className={navItem}><Activity className="size-4" />Activity</Link>
          <div className="px-2.5 pb-1 pt-4 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">Settings</div>
          <Link to="/settings/users" className={navItem}><Users className="size-4" />Users & roles</Link>
          <Link to="/settings/github" className={navItem}><GitBranch className="size-4" />GitHub App</Link>
          <Link to="/settings/agents" className={navItem}><Bot className="size-4" />AI agents</Link>
          <Link to="/settings/audit" className={navItem}><ScrollText className="size-4" />Audit log</Link>
          <Link to="/settings/backups" className={navItem}><Cloud className="size-4" />Backups</Link>
          <Link to="/settings/general" className={navItem}><Settings className="size-4" />General</Link>
        </nav>
        <div className="border-t p-3 text-xs text-muted-foreground">
          {s && (
            <div className="mb-2 flex items-center justify-between">
              <span>{s.machinesUp}/{s.machinesTotal} machines up</span>
              <span>{s.replicasRunning}/{s.replicasDesired} replicas</span>
            </div>
          )}
          <div className="flex items-center gap-1.5">
            <span className={cn('size-1.5 rounded-full', live ? 'bg-success' : 'bg-muted-foreground')} />
            {live ? 'Live updates' : 'Polling'}
            {s?.version && <span className="ml-auto">v{s.version}</span>}
          </div>
        </div>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center gap-3 border-b bg-card/60 px-4 backdrop-blur">
          <button
            className="flex h-9 w-full max-w-md cursor-pointer items-center gap-2 rounded-md border bg-background px-3 text-sm text-muted-foreground hover:bg-muted"
            onClick={() => window.dispatchEvent(new Event(openPaletteEvent))}
            aria-label="Open command palette"
          >
            <Search className="size-4" />
            <span className="flex-1 text-left">Search or jump to…</span>
            <kbd className="rounded border bg-muted px-1.5 text-[11px]">⌘K</kbd>
          </button>
          <div className="ml-auto flex items-center gap-2">
            {isMock && <Badge tone="warning">mock data</Badge>}
            <Button variant="ghost" size="icon" onClick={toggleTheme} aria-label="Toggle theme">{theme === 'dark' ? <Sun /> : <Moon />}</Button>
            {user ? (
              <div className="flex items-center gap-2">
                <div className="hidden text-right text-xs leading-tight sm:block">
                  <div className="font-medium">{user.name || user.email}</div>
                  <div className="text-muted-foreground">{user.email}</div>
                </div>
                <Button variant="ghost" size="icon" aria-label="Sign out" onClick={async () => { await logout(); void nav({ to: '/login' }) }}><LogOut /></Button>
              </div>
            ) : (
              authDisabled && <Badge title="AuthService is not available on this node; access is network-trusted">no auth</Badge>
            )}
          </div>
        </header>
        <main className="min-h-0 flex-1 overflow-auto">
          <Outlet />
        </main>
      </div>
      <CommandPalette />
    </div>
  )
}

export function PageHeader({ title, description, actions }: { title: string; description?: string; actions?: React.ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
      <div>
        <h1 className="text-xl font-semibold tracking-tight">{title}</h1>
        {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  )
}

export function Page({ children, wide }: { children: React.ReactNode; wide?: boolean }) {
  return <div className={cn('mx-auto p-6', wide ? 'max-w-6xl' : 'max-w-4xl')}>{children}</div>
}
